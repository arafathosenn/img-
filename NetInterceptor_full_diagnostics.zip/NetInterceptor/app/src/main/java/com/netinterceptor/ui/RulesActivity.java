package com.netinterceptor.ui;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.netinterceptor.R;
import com.netinterceptor.data.model.InterceptRule;
import com.netinterceptor.data.repository.AppDatabase;
import com.netinterceptor.service.InterceptorService;
import com.netinterceptor.ui.adapter.InterceptRuleAdapter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RulesActivity extends AppCompatActivity {

    private int appId;
    private AppDatabase db;
    private InterceptRuleAdapter adapter;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rules);

        appId = getIntent().getIntExtra("app_id", -1);
        String label = getIntent().getStringExtra("app_label");
        String pkg = getIntent().getStringExtra("pkg");

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(label != null ? label : "Rules");
            getSupportActionBar().setSubtitle(pkg);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        db = AppDatabase.getInstance(this);

        RecyclerView rv = findViewById(R.id.rv_rules);
        FloatingActionButton fab = findViewById(R.id.fab_add_rule);

        adapter = new InterceptRuleAdapter(
            rule -> showRuleDialog(rule),
            rule -> toggleRule(rule),
            rule -> confirmDeleteRule(rule)
        );
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        db.interceptRuleDao().getRulesForApp(appId).observe(this, rules -> adapter.setRules(rules));

        fab.setOnClickListener(v -> showRuleDialog(null));
    }

    private void showRuleDialog(InterceptRule existing) {
        View v = getLayoutInflater().inflate(R.layout.dialog_rule, null);
        EditText etUrl = v.findViewById(R.id.et_url);
        Spinner spMatch = v.findViewById(R.id.sp_match_type);
        EditText etCode = v.findViewById(R.id.et_response_code);
        EditText etBody = v.findViewById(R.id.et_response_body);
        EditText etHeaders = v.findViewById(R.id.et_response_headers);
        EditText etDesc = v.findViewById(R.id.et_description);

        String[] matchTypes = {"CONTAINS", "EXACT", "STARTS_WITH", "ENDS_WITH", "REGEX"};
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, matchTypes);
        spMatch.setAdapter(spinnerAdapter);

        if (existing != null) {
            etUrl.setText(existing.urlPattern);
            etCode.setText(String.valueOf(existing.fakeResponseCode));
            etBody.setText(existing.fakeResponseBody);
            etHeaders.setText(existing.fakeResponseHeaders);
            etDesc.setText(existing.description);
            for (int i = 0; i < matchTypes.length; i++) {
                if (matchTypes[i].equals(existing.matchType)) { spMatch.setSelection(i); break; }
            }
        } else {
            etCode.setText("200");
            etBody.setText("{\n  \"success\": true,\n  \"licensed\": true\n}");
            etHeaders.setText("{\"Content-Type\":\"application/json\"}");
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Add Rule" : "Edit Rule")
                .setView(v)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn -> {
            String url = etUrl.getText().toString().trim();
            String body = etBody.getText().toString().trim();
            if (url.isEmpty() || body.isEmpty()) {
                Toast.makeText(this, "URL and body required", Toast.LENGTH_SHORT).show();
                return;
            }
            int code = 200;
            try { code = Integer.parseInt(etCode.getText().toString().trim()); } catch (Exception ignored) {}

            final InterceptRule rule = new InterceptRule(
                    appId, url, matchTypes[spMatch.getSelectedItemPosition()],
                    code, body, etHeaders.getText().toString().trim(),
                    etDesc.getText().toString().trim());

            executor.submit(() -> {
                if (existing != null) db.interceptRuleDao().deleteById(existing.id);
                db.interceptRuleDao().insertRule(rule);
                reloadService();
            });
            dialog.dismiss();
        }));

        dialog.show();
    }

    private void toggleRule(InterceptRule rule) {
        executor.submit(() -> {
            rule.isEnabled = !rule.isEnabled;
            db.interceptRuleDao().updateRule(rule);
            reloadService();
        });
    }

    private void confirmDeleteRule(InterceptRule rule) {
        new AlertDialog.Builder(this)
                .setTitle("Delete rule?")
                .setMessage(rule.urlPattern)
                .setPositiveButton("Delete", (d, w) -> executor.submit(() -> {
                    db.interceptRuleDao().deleteRule(rule);
                    reloadService();
                }))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void reloadService() {
        if (InterceptorService.instance != null) InterceptorService.instance.reloadRules();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() { executor.shutdownNow(); super.onDestroy(); }
}
