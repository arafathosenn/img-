package com.netinterceptor.data.repository;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.netinterceptor.data.model.TargetApp;
import java.util.List;

@Dao
public interface TargetAppDao {
    @Query("SELECT * FROM target_apps ORDER BY createdAt DESC")
    LiveData<List<TargetApp>> getAllApps();

    @Query("SELECT * FROM target_apps WHERE isEnabled = 1")
    List<TargetApp> getEnabledApps();

    @Query("SELECT * FROM target_apps WHERE id = :id")
    TargetApp getAppById(int id);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertApp(TargetApp app);

    @Update
    void updateApp(TargetApp app);

    @Delete
    void deleteApp(TargetApp app);

    @Query("DELETE FROM target_apps WHERE id = :id")
    void deleteById(int id);
}
