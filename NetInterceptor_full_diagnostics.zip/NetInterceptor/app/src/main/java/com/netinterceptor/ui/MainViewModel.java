package com.netinterceptor.ui;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Build;
import androidx.lifecycle.*;
import com.netinterceptor.data.model.TargetApp;
import com.netinterceptor.data.repository.AppDatabase;
import com.netinterceptor.root.RootManager;
import com.netinterceptor.service.InterceptorService;
import com.netinterceptor.service.DiagnosticsLog;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainViewModel extends AndroidViewModel {
    private final AppDatabase db;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final MutableLiveData<Boolean> rootedLive = new MutableLiveData<>();

    public MainViewModel(Application app) {
        super(app);
        db = AppDatabase.getInstance(app);
        executor.submit(() -> {
            DiagnosticsLog.add("Checking Magisk/root access...");
            boolean root = RootManager.isRooted();
            DiagnosticsLog.add(root ? "ROOT GRANTED" : "ROOT DENIED");
            rootedLive.postValue(root);
        });
    }

    public LiveData<List<TargetApp>> getAllApps() {
        return db.targetAppDao().getAllApps();
    }

    public LiveData<Boolean> isRooted() { return rootedLive; }

    public void addApp(String pkg, String label) {
        final String packageName = pkg == null ? "" : pkg.trim();
        DiagnosticsLog.add("Target package entered: " + packageName);
        executor.submit(() -> {
            try {
                if (packageName.isEmpty()) {
                    DiagnosticsLog.add("ERROR: package name is empty");
                } else {
                    getApplication().getPackageManager().getPackageInfo(packageName, 0);
                    DiagnosticsLog.add("PACKAGE FOUND: " + packageName + " is installed");
                }
            } catch (Exception e) {
                DiagnosticsLog.add("PACKAGE NOT FOUND: " + packageName + " (" + e.getClass().getSimpleName() + ")");
            }
            // Keep the previous add behavior; diagnostics must not silently remove this feature.
            db.targetAppDao().insertApp(new TargetApp(packageName, label));
            DiagnosticsLog.add("Target saved: " + packageName);
        });
    }

    public void toggleApp(TargetApp app) {
        executor.submit(() -> {
            app.isEnabled = !app.isEnabled;
            db.targetAppDao().updateApp(app);
            reloadService();
        });
    }

    public void deleteApp(TargetApp app) {
        executor.submit(() -> {
            db.interceptRuleDao().deleteRulesForApp(app.id);
            db.targetAppDao().deleteApp(app);
            reloadService();
        });
    }

    public void startService(Context ctx) {
        DiagnosticsLog.add("User requested interceptor START");
        Intent intent = new Intent(ctx, InterceptorService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(intent);
        } else {
            ctx.startService(intent);
        }
    }

    public void stopService(Context ctx) {
        DiagnosticsLog.add("User requested interceptor STOP");
        Intent intent = new Intent(ctx, InterceptorService.class);
        intent.setAction("STOP");
        ctx.startService(intent);
    }

    private void reloadService() {
        if (InterceptorService.instance != null) {
            InterceptorService.instance.reloadRules();
        }
    }

    public List<String[]> getInstalledApps(Context ctx) {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = ctx.getPackageManager().queryIntentActivities(intent, 0);
        List<String[]> result = new ArrayList<>();
        for (ResolveInfo ri : list) {
            String pkg = ri.activityInfo.packageName;
            String label = ri.loadLabel(ctx.getPackageManager()).toString();
            result.add(new String[]{pkg, label});
        }
        result.sort((a, b) -> a[1].compareToIgnoreCase(b[1]));
        return result;
    }
}
