package com.netinterceptor.data.repository;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.netinterceptor.data.model.InterceptRule;
import java.util.List;

@Dao
public interface InterceptRuleDao {
    @Query("SELECT * FROM intercept_rules WHERE targetAppId = :appId ORDER BY id DESC")
    LiveData<List<InterceptRule>> getRulesForApp(int appId);

    @Query("SELECT * FROM intercept_rules WHERE targetAppId = :appId AND isEnabled = 1")
    List<InterceptRule> getEnabledRulesForApp(int appId);

    @Query("SELECT * FROM intercept_rules WHERE isEnabled = 1")
    List<InterceptRule> getAllEnabledRules();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertRule(InterceptRule rule);

    @Update
    void updateRule(InterceptRule rule);

    @Delete
    void deleteRule(InterceptRule rule);

    @Query("DELETE FROM intercept_rules WHERE targetAppId = :appId")
    void deleteRulesForApp(int appId);

    @Query("DELETE FROM intercept_rules WHERE id = :id")
    void deleteById(int id);
}
