package com.netinterceptor.ui.adapter;

import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.netinterceptor.R;
import com.netinterceptor.data.model.TargetApp;
import java.util.ArrayList;
import java.util.List;

public class TargetAppAdapter extends RecyclerView.Adapter<TargetAppAdapter.VH> {

    public interface OnClick { void onClick(TargetApp app); }

    private final OnClick onItem, onToggle, onDelete;
    private List<TargetApp> apps = new ArrayList<>();

    public TargetAppAdapter(OnClick onItem, OnClick onToggle, OnClick onDelete) {
        this.onItem = onItem;
        this.onToggle = onToggle;
        this.onDelete = onDelete;
    }

    public void setApps(List<TargetApp> list) {
        apps = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_target_app, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        TargetApp app = apps.get(pos);
        h.tvLabel.setText(app.appLabel);
        h.tvPkg.setText(app.packageName);
        h.swEnabled.setChecked(app.isEnabled);
        h.itemView.setOnClickListener(v -> onItem.onClick(app));
        h.swEnabled.setOnCheckedChangeListener((btn, checked) -> onToggle.onClick(app));
        h.btnDelete.setOnClickListener(v -> onDelete.onClick(app));
    }

    @Override
    public int getItemCount() { return apps.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvLabel, tvPkg;
        Switch swEnabled;
        ImageButton btnDelete;
        VH(View v) {
            super(v);
            tvLabel = v.findViewById(R.id.tv_app_label);
            tvPkg = v.findViewById(R.id.tv_pkg);
            swEnabled = v.findViewById(R.id.sw_enabled);
            btnDelete = v.findViewById(R.id.btn_delete);
        }
    }
}
