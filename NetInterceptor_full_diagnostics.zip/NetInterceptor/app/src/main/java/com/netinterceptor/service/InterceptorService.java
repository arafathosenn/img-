package com.netinterceptor.service;

import android.app.*;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.netinterceptor.R;
import com.netinterceptor.data.model.InterceptRule;
import com.netinterceptor.data.model.TargetApp;
import com.netinterceptor.data.repository.AppDatabase;
import com.netinterceptor.root.RootManager;
import com.netinterceptor.ui.MainActivity;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class InterceptorService extends Service {
    private static final String TAG = "InterceptorService";
    private static final int NOTIF_ID = 1;
    private static final String CHANNEL_ID = "interceptor_ch";
    public static final int HTTP_PORT  = 8080;
    public static final int HTTPS_PORT = 8081;

    public static InterceptorService instance;
    public static boolean isRunning = false;
    public final List<String> logs = Collections.synchronizedList(new ArrayList<>());

    private ProxyServer proxy;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        DiagnosticsLog.add("SERVICE: onCreate");
        proxy = new ProxyServer(HTTP_PORT, HTTPS_PORT, (url, intercepted, code) -> {
            String entry = (intercepted ? "[INTERCEPT] " : "[PASS] ") + code + " " + url;
            logs.add(0, entry);
            DiagnosticsLog.add("API " + entry);
            if (logs.size() > 500) logs.remove(logs.size() - 1);
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        DiagnosticsLog.add("SERVICE: start command received");
        startForegroundNotif();
        isRunning = false;
        executor.submit(this::startInterception);
        return START_STICKY;
    }

    private void startInterception() {
        DiagnosticsLog.add("STARTUP: checking root permission");
        if (!RootManager.isRooted()) {
            DiagnosticsLog.add("STARTUP FAILED: root permission denied");
            isRunning = false;
            Log.e(TAG, "No root!");
            return;
        }
        DiagnosticsLog.add("STARTUP: root granted");
        reloadRules();
        DiagnosticsLog.add("STARTUP: starting proxy listeners on HTTP=" + HTTP_PORT + ", HTTPS=" + HTTPS_PORT);
        proxy.start();
        DiagnosticsLog.add("STARTUP: proxy start requested; checking target package UID and redirect rules");
        setupIptables();
        DiagnosticsLog.add("STARTUP: setupIptables finished");
        // Listener threads bind asynchronously; report running only after a bind is observed.
        for (int i = 0; i < 30 && !proxy.isHttpListening() && !proxy.isHttpsListening(); i++) {
            try { Thread.sleep(100); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
        }
        isRunning = proxy.isHttpListening() || proxy.isHttpsListening();
        DiagnosticsLog.add(isRunning ? "SERVICE READY: HTTP=" + proxy.isHttpListening() + ", HTTPS=" + proxy.isHttpsListening()
                : "SERVICE START FAILED: no proxy listener could bind; check listener error above");
    }

    public void reloadRules() {
        AppDatabase db = AppDatabase.getInstance(this);
        List<TargetApp> apps = db.targetAppDao().getEnabledApps();
        List<InterceptRule> all = new ArrayList<>();
        for (TargetApp app : apps) {
            all.addAll(db.interceptRuleDao().getEnabledRulesForApp(app.id));
        }
        proxy.rules = all;
        DiagnosticsLog.add("RULES: loaded " + all.size() + " enabled rule(s) for " + apps.size() + " enabled target(s)");
        Log.d(TAG, "Rules loaded: " + all.size());
    }

    private void setupIptables() {
        AppDatabase db = AppDatabase.getInstance(this);
        List<TargetApp> apps = db.targetAppDao().getEnabledApps();

        DiagnosticsLog.add("IPTABLES: clearing previous OUTPUT rules using existing project behavior");
        // Clear old rules first
        RootManager.flushNatOutput();

        for (TargetApp app : apps) {
            DiagnosticsLog.add("TARGET: checking " + app.packageName + " (enabled=" + app.isEnabled + ")");
            int uid = RootManager.getUidForPackage(app.packageName);
            if (uid >= 0) {
                RootManager.setupIptablesForUid(uid, HTTP_PORT, HTTPS_PORT);
                DiagnosticsLog.add("TARGET READY: " + app.packageName + " uid=" + uid);
                Log.d(TAG, "iptables set for " + app.packageName + " uid=" + uid);
            } else {
                DiagnosticsLog.add("TARGET ERROR: UID not found for " + app.packageName);
                Log.w(TAG, "Could not find uid for " + app.packageName);
            }
        }
    }

    /** Called from DiscoverActivity to get the URLs proxy has seen */
    public List<String> getDiscoveredUrls() {
        if (proxy != null) return new ArrayList<>(proxy.discoveredUrls);
        return new ArrayList<>();
    }

    public void clearDiscoveredUrls() {
        if (proxy != null) proxy.discoveredUrls.clear();
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        DiagnosticsLog.add("SERVICE: onDestroy; stopping proxy and cleaning existing rules");
        instance = null;
        RootManager.flushNatOutput();
        if (proxy != null) proxy.stop();
        executor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void startForegroundNotif() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Interceptor", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);

        Intent stopIntent = new Intent(this, InterceptorService.class);
        stopIntent.setAction("STOP");
        PendingIntent stopPi = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE);

        Notification notif = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("NetInterceptor Active")
                .setContentText("Intercepting traffic")
                .setSmallIcon(R.drawable.ic_shield)
                .setContentIntent(openPi)
                .addAction(0, "Stop", stopPi)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIF_ID, notif);
        }
    }
}
