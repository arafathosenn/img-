package com.netinterceptor.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.netinterceptor.R;
import com.netinterceptor.service.InterceptorService;
import com.netinterceptor.service.DiagnosticsLog;
import java.util.ArrayList;
import java.util.List;

public class LogsActivity extends AppCompatActivity {

    private ArrayAdapter<String> adapter;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = this::refreshLogs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logs);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Intercept Logs");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        ListView lv = findViewById(R.id.lv_logs);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        lv.setAdapter(adapter);

        findViewById(R.id.btn_clear_logs).setOnClickListener(v -> {
            DiagnosticsLog.clear();
            if (InterceptorService.instance != null) InterceptorService.instance.logs.clear();
            adapter.clear();
        });
    }

    private void refreshLogs() {
        List<String> logs = DiagnosticsLog.snapshot();
        if (InterceptorService.instance != null) {
            logs.addAll(InterceptorService.instance.logs);
        }
        adapter.clear();
        adapter.addAll(logs);
        handler.postDelayed(refresh, 1000);
    }

    @Override
    protected void onResume() { super.onResume(); handler.post(refresh); }

    @Override
    protected void onPause() { super.onPause(); handler.removeCallbacks(refresh); }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }
}
