package com.netinterceptor.root;

import android.util.Log;
import com.topjohnwu.superuser.Shell;
import com.netinterceptor.service.DiagnosticsLog;
import java.util.List;

public class RootManager {
    private static final String TAG = "RootManager";

    static {
        Shell.enableVerboseLogging = false;
        Shell.setDefaultBuilder(Shell.Builder.create()
                .setFlags(Shell.FLAG_REDIRECT_STDERR)
                .setTimeout(10));
    }

    public static boolean isRooted() {
        try {
            boolean rooted = Shell.getShell().isRoot();
            DiagnosticsLog.add(rooted ? "RootManager: root shell available" : "RootManager: root shell unavailable");
            return rooted;
        } catch (Exception e) {
            DiagnosticsLog.add("RootManager root check ERROR: " + e);
            return false;
        }
    }

    public static boolean runCommand(String cmd) {
        DiagnosticsLog.add("ROOT CMD: " + cmd);
        Shell.Result result = Shell.cmd(cmd).exec();
        DiagnosticsLog.add("ROOT CMD RESULT: " + (result.isSuccess() ? "SUCCESS" : "FAILED") + " | " + cmd);
        if (!result.getErr().isEmpty()) DiagnosticsLog.add("ROOT CMD STDERR: " + result.getErr());
        return result.isSuccess();
    }

    public static List<String> runCommandOutput(String cmd) {
        DiagnosticsLog.add("ROOT QUERY: " + cmd);
        Shell.Result result = Shell.cmd(cmd).exec();
        if (!result.isSuccess()) DiagnosticsLog.add("ROOT QUERY FAILED: " + cmd + " | " + result.getErr());
        return result.getOut();
    }

    public static int getMyUid() {
        try {
            List<String> out = runCommandOutput("id -u");
            if (!out.isEmpty()) {
                return Integer.parseInt(out.get(0).trim().replaceAll("[^0-9]", ""));
            }
        } catch (Exception e) {
            Log.e(TAG, "getMyUid error: " + e.getMessage());
        }
        return -1;
    }

    public static int getUidForPackage(String packageName) {
        DiagnosticsLog.add("Resolving UID for package: " + packageName);
        try {
            List<String> out = runCommandOutput(
                "cat /data/system/packages.xml | grep 'name=\"" + packageName + "\"' " +
                "| grep -o 'userId=\"[0-9]*\"' | grep -o '[0-9]*'"
            );
            if (!out.isEmpty() && out.get(0) != null && !out.get(0).trim().isEmpty()) {
                int uid = Integer.parseInt(out.get(0).trim());
                DiagnosticsLog.add("UID FOUND: " + packageName + " -> " + uid);
                return uid;
            }
        } catch (Exception e) {
            Log.e(TAG, "getUid error: " + e.getMessage());
        }
        DiagnosticsLog.add("UID NOT FOUND: " + packageName);
        return -1;
    }

    /**
     * Flush OUTPUT chain, then set:
     *   1. RETURN rule for OUR OWN uid (avoid infinite redirect loop)
     *   2. REDIRECT rules for each target uid
     */
    public static boolean setupIptablesForUid(int uid, int httpPort, int httpsPort) {
        int myUid = getMyUid();

        // Exclude proxy app itself from redirect — prevents infinite loop
        if (myUid >= 0) {
            runCommand("iptables -t nat -I OUTPUT 1 -m owner --uid-owner " + myUid + " -j RETURN");
            Log.d(TAG, "Excluded own uid=" + myUid + " from redirect");
        }

        boolean ok1 = runCommand(
            "iptables -t nat -A OUTPUT -m owner --uid-owner " + uid +
            " -p tcp --dport 80 -j REDIRECT --to-port " + httpPort);
        boolean ok2 = runCommand(
            "iptables -t nat -A OUTPUT -m owner --uid-owner " + uid +
            " -p tcp --dport 443 -j REDIRECT --to-port " + httpsPort);

        Log.d(TAG, "iptables uid=" + uid + " HTTP=" + ok1 + " HTTPS=" + ok2);
        DiagnosticsLog.add("iptables result for uid=" + uid + ": HTTP=" + ok1 + ", HTTPS=" + ok2);
        return ok1 && ok2;
    }

    public static void flushNatOutput() {
        runCommand("iptables -t nat -F OUTPUT 2>/dev/null || true");
    }

    /**
     * Install our CA cert into the system trust store so the target app
     * accepts our proxy's self-signed TLS cert without SSL errors.
     * Requires /system to be remounted rw.
     * certPath = absolute path to the PEM file (e.g. /data/local/tmp/proxy_ca.pem)
     */
    public static boolean installCaCert(String certPath, String certHash) {
        // certHash = openssl x509 -subject_hash_old -in cert.pem | head -1
        // Android system store filename format: <hash>.0
        String dest = "/system/etc/security/cacerts/" + certHash + ".0";
        boolean remount = runCommand("mount -o rw,remount /system");
        if (!remount) {
            // Try magisk overlay path
            runCommand("magisk --sqlite 'INSERT OR IGNORE INTO policies VALUES(1,\"1\",\"1\",\"1\",\"1\")'");
            remount = runCommand("mount -o rw,remount /system");
        }
        boolean copy    = runCommand("cp " + certPath + " " + dest);
        boolean chmod   = runCommand("chmod 644 " + dest);
        boolean remountRo = runCommand("mount -o ro,remount /system");
        Log.d(TAG, "CA install: remount=" + remount + " copy=" + copy + " chmod=" + chmod);
        return copy && chmod;
    }
}
