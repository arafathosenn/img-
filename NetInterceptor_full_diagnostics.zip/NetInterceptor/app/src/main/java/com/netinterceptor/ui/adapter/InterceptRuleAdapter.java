package com.netinterceptor.ui.adapter;

import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.netinterceptor.R;
import com.netinterceptor.data.model.InterceptRule;
import java.util.ArrayList;
import java.util.List;

public class InterceptRuleAdapter extends RecyclerView.Adapter<InterceptRuleAdapter.VH> {

    public interface OnClick { void onClick(InterceptRule rule); }

    private final OnClick onEdit, onToggle, onDelete;
    private List<InterceptRule> rules = new ArrayList<>();

    public InterceptRuleAdapter(OnClick onEdit, OnClick onToggle, OnClick onDelete) {
        this.onEdit = onEdit;
        this.onToggle = onToggle;
        this.onDelete = onDelete;
    }

    public void setRules(List<InterceptRule> list) {
        rules = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_rule, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        InterceptRule rule = rules.get(pos);
        h.tvUrl.setText(rule.urlPattern);
        h.tvCode.setText(String.valueOf(rule.fakeResponseCode));
        h.tvMatch.setText(rule.matchType);
        h.tvDesc.setText(rule.description != null ? rule.description : "");
        h.tvBody.setText(rule.fakeResponseBody.length() > 60
                ? rule.fakeResponseBody.substring(0, 60) + "..." : rule.fakeResponseBody);
        h.swEnabled.setChecked(rule.isEnabled);
        h.itemView.setOnClickListener(v -> onEdit.onClick(rule));
        h.swEnabled.setOnCheckedChangeListener((btn, c) -> onToggle.onClick(rule));
        h.btnDelete.setOnClickListener(v -> onDelete.onClick(rule));
    }

    @Override
    public int getItemCount() { return rules.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvUrl, tvCode, tvMatch, tvDesc, tvBody;
        Switch swEnabled;
        ImageButton btnDelete;
        VH(View v) {
            super(v);
            tvUrl = v.findViewById(R.id.tv_url);
            tvCode = v.findViewById(R.id.tv_code);
            tvMatch = v.findViewById(R.id.tv_match);
            tvDesc = v.findViewById(R.id.tv_desc);
            tvBody = v.findViewById(R.id.tv_body);
            swEnabled = v.findViewById(R.id.sw_rule_enabled);
            btnDelete = v.findViewById(R.id.btn_rule_delete);
        }
    }
}
