package com.netinterceptor.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.netinterceptor.R;
import com.netinterceptor.data.model.InterceptRule;
import com.netinterceptor.data.repository.AppDatabase;
import com.netinterceptor.service.InterceptorService;
import com.netinterceptor.service.DiagnosticsLog;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DiscoverActivity extends AppCompatActivity {

    private ArrayAdapter<String> adapter;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = this::refreshUrls;
    private int appId;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discover);

        appId = getIntent().getIntExtra("app_id", -1);
        String label = getIntent().getStringExtra("app_label");

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Discovered APIs");
            getSupportActionBar().setSubtitle(label);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        TextView tvDiscoveryStatus = findViewById(R.id.tv_discovery_status);
        if (InterceptorService.instance == null) {
            tvDiscoveryStatus.setText("NOT CONNECTED: interceptor service is not running");
            DiagnosticsLog.add("DISCOVERY OPEN FAILED: service instance is null");
        } else if (InterceptorService.instance.isRunning) {
            tvDiscoveryStatus.setText("CONNECTED: waiting for target app requests...");
            DiagnosticsLog.add("DISCOVERY STARTED for app id=" + appId + "; waiting for requests");
        } else {
            tvDiscoveryStatus.setText("SERVICE NOT READY: proxy listener has not started");
            DiagnosticsLog.add("DISCOVERY OPENED BUT SERVICE IS NOT READY");
        }

        ListView lv = findViewById(R.id.lv_discovered);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        lv.setAdapter(adapter);

        findViewById(R.id.btn_clear_discovered).setOnClickListener(v -> {
            if (InterceptorService.instance != null)
                InterceptorService.instance.clearDiscoveredUrls();
            adapter.clear();
        });

        // Tap a URL → immediately open rule dialog pre-filled with that URL
        lv.setOnItemClickListener((parent, view, pos, id) -> {
            String url = adapter.getItem(pos);
            if (url != null) showQuickRuleDialog(url);
        });
    }

    private void refreshUrls() {
        if (InterceptorService.instance != null) {
            List<String> urls = InterceptorService.instance.getDiscoveredUrls();
            TextView status = findViewById(R.id.tv_discovery_status);
            if (status != null) status.setText(!InterceptorService.instance.isRunning ? "SERVICE NOT READY: check Logs" : (urls.isEmpty() ? "CONNECTED: waiting for target app requests... (0 URLs)" : "TRAFFIC DETECTED: " + urls.size() + " URL(s)"));
            adapter.clear();
            adapter.addAll(urls);
        } else {
            TextView status = findViewById(R.id.tv_discovery_status);
            if (status != null) status.setText("NOT CONNECTED: interceptor service stopped");
        }
        handler.postDelayed(refresh, 1000);
    }

    private void showQuickRuleDialog(String url) {
        android.view.View v = getLayoutInflater().inflate(R.layout.dialog_rule, null);
        EditText etUrl     = v.findViewById(R.id.et_url);
        Spinner  spMatch   = v.findViewById(R.id.sp_match_type);
        EditText etCode    = v.findViewById(R.id.et_response_code);
        EditText etBody    = v.findViewById(R.id.et_response_body);
        EditText etHeaders = v.findViewById(R.id.et_response_headers);
        EditText etDesc    = v.findViewById(R.id.et_description);

        // Pre-fill with discovered URL
        etUrl.setText(url);
        etCode.setText("200");
        etBody.setText("{\n  \"success\": true,\n  \"licensed\": true\n}");
        etHeaders.setText("{\"Content-Type\":\"application/json\"}");

        String[] matchTypes = {"CONTAINS", "EXACT", "STARTS_WITH", "ENDS_WITH", "REGEX"};
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, matchTypes);
        spMatch.setAdapter(spinnerAdapter);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Add Intercept Rule")
                .setView(v)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(btn -> {
                    String urlPattern = etUrl.getText().toString().trim();
                    String body       = etBody.getText().toString().trim();
                    if (urlPattern.isEmpty() || body.isEmpty()) {
                        Toast.makeText(this, "URL and body required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int code = 200;
                    try { code = Integer.parseInt(etCode.getText().toString().trim()); }
                    catch (Exception ignored) {}

                    final InterceptRule rule = new InterceptRule(
                            appId,
                            urlPattern,
                            matchTypes[spMatch.getSelectedItemPosition()],
                            code,
                            body,
                            etHeaders.getText().toString().trim(),
                            etDesc.getText().toString().trim());

                    DiagnosticsLog.add("DISCOVERY: saving rule for URL " + urlPattern);
                    executor.submit(() -> {
                        AppDatabase.getInstance(this).interceptRuleDao().insertRule(rule);
                        if (InterceptorService.instance != null)
                            InterceptorService.instance.reloadRules();
                    });
                    Toast.makeText(this, "Rule saved!", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }));

        dialog.show();
    }

    @Override protected void onResume() { super.onResume(); handler.post(refresh); }
    @Override protected void onPause()  { super.onPause();  handler.removeCallbacks(refresh); }
    @Override protected void onDestroy(){ executor.shutdownNow(); super.onDestroy(); }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }
}
