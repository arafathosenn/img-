package com.netinterceptor.data.repository;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import com.netinterceptor.data.model.InterceptRule;
import com.netinterceptor.data.model.TargetApp;

@Database(entities = {TargetApp.class, InterceptRule.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract TargetAppDao targetAppDao();
    public abstract InterceptRuleDao interceptRuleDao();

    private static volatile AppDatabase INSTANCE;

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "netinterceptor.db"
                    ).build();
                }
            }
        }
        return INSTANCE;
    }
}
