package com.netinterceptor.data.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "intercept_rules")
public class InterceptRule {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public int targetAppId;
    public String urlPattern;
    public String matchType;   // EXACT | CONTAINS | STARTS_WITH | ENDS_WITH | REGEX
    public int fakeResponseCode;
    public String fakeResponseBody;
    public String fakeResponseHeaders;
    public boolean isEnabled;
    public String description;

    public InterceptRule() {}

    public InterceptRule(int targetAppId, String urlPattern, String matchType,
                         int fakeResponseCode, String fakeResponseBody,
                         String fakeResponseHeaders, String description) {
        this.targetAppId = targetAppId;
        this.urlPattern = urlPattern;
        this.matchType = matchType;
        this.fakeResponseCode = fakeResponseCode;
        this.fakeResponseBody = fakeResponseBody;
        this.fakeResponseHeaders = fakeResponseHeaders;
        this.isEnabled = true;
        this.description = description;
    }
}
