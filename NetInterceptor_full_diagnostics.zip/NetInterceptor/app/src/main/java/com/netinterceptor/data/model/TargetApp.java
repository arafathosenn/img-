package com.netinterceptor.data.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "target_apps")
public class TargetApp {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String packageName;
    public String appLabel;
    public boolean isEnabled;
    public long createdAt;

    public TargetApp() {}

    public TargetApp(String packageName, String appLabel) {
        this.packageName = packageName;
        this.appLabel = appLabel;
        this.isEnabled = true;
        this.createdAt = System.currentTimeMillis();
    }
}
