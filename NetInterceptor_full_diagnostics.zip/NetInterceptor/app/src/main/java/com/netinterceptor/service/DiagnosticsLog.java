package com.netinterceptor.service;

import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.*;

/** Additive diagnostic log. Does not alter interception decisions. */
public final class DiagnosticsLog {
    private static final String TAG = "NetInterceptorDiag";
    private static final List<String> ENTRIES = Collections.synchronizedList(new ArrayList<>());
    private DiagnosticsLog() {}
    public static void add(String message) {
        String line = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()) + "  " + message;
        ENTRIES.add(0, line);
        while (ENTRIES.size() > 1000) ENTRIES.remove(ENTRIES.size()-1);
        Log.i(TAG, message);
    }
    public static List<String> snapshot() { synchronized (ENTRIES) { return new ArrayList<>(ENTRIES); } }
    public static void clear() { ENTRIES.clear(); }
}
