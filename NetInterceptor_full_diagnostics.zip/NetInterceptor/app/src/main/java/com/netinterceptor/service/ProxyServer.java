package com.netinterceptor.service;

import android.util.Log;
import com.netinterceptor.data.model.InterceptRule;
import org.json.JSONObject;

import java.io.*;
import java.math.BigInteger;
import java.net.*;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.concurrent.*;
import javax.net.ssl.*;

public class ProxyServer {
    private static final String TAG = "ProxyServer";

    private final int httpPort;
    private final int httpsPort;
    private ServerSocket httpServer;
    private ServerSocket httpsServer;
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private volatile boolean running = false;
    private volatile boolean httpListening = false;
    private volatile boolean httpsListening = false;

    // All intercept rules (reloaded from service)
    public volatile List<InterceptRule> rules = new ArrayList<>();

    // Sniff-only log: URLs seen but NOT yet matched by any rule
    public final List<String> discoveredUrls = Collections.synchronizedList(new ArrayList<>());

    public interface LogCallback {
        void onLog(String url, boolean intercepted, int code);
    }

    private final LogCallback logCallback;
    private SSLContext serverSslContext;   // used by proxy to present cert to target app
    private SSLSocketFactory forwardSslFactory; // used to forward to real server (trust-all)

    public ProxyServer(int httpPort, int httpsPort, LogCallback logCallback) {
        this.httpPort = httpPort;
        this.httpsPort = httpsPort;
        this.logCallback = logCallback;
        DiagnosticsLog.add("PROXY: constructing listeners (HTTP=" + httpPort + ", HTTPS=" + httpsPort + ")");
        try {
            KeyPair kp = generateRsaKeyPair();
            X509Certificate cert = buildSelfSignedCert(kp);
            serverSslContext = buildServerContext(kp, cert);
            forwardSslFactory = buildTrustAllFactory();
        } catch (Exception e) {
            DiagnosticsLog.add("PROXY SSL INIT ERROR: " + e);
            Log.e(TAG, "SSL init error: " + e.getMessage());
        }
    }

    // ── Start / Stop ─────────────────────────────────────────────────────────

    public void start() {
        running = true;
        DiagnosticsLog.add("PROXY: start requested");
        executor.submit(this::runHttpServer);
        executor.submit(this::runHttpsServer);
        Log.d(TAG, "Proxy started HTTP:" + httpPort + " HTTPS:" + httpsPort);
    }

    public boolean isHttpListening() { return httpListening; }
    public boolean isHttpsListening() { return httpsListening; }

    public void stop() {
        running = false;
        httpListening = false;
        httpsListening = false;
        try { if (httpServer  != null) httpServer.close();  } catch (Exception ignored) {}
        try { if (httpsServer != null) httpsServer.close(); } catch (Exception ignored) {}
        executor.shutdownNow();
    }

    // ── Listeners ────────────────────────────────────────────────────────────

    private void runHttpServer() {
        try {
            httpServer = new ServerSocket(httpPort);
            httpServer.setReuseAddress(true);
            httpListening = true;
            DiagnosticsLog.add("PROXY LISTENING: HTTP port " + httpPort);
            while (running) {
                Socket client = httpServer.accept();
                executor.submit(() -> handleHttpClient(client));
            }
        } catch (Exception e) {
            httpListening = false;
            if (running) { DiagnosticsLog.add("HTTP LISTENER ERROR: " + e); Log.e(TAG, "HTTP listener: " + e.getMessage()); }
        }
    }

    private void runHttpsServer() {
        try {
            if (serverSslContext == null) {
                Log.e(TAG, "No SSL context — HTTPS proxy disabled");
                return;
            }
            SSLServerSocketFactory ssf = serverSslContext.getServerSocketFactory();
            SSLServerSocket sss = (SSLServerSocket) ssf.createServerSocket(httpsPort);
            sss.setReuseAddress(true);
            httpsServer = sss;
            httpsListening = true;
            DiagnosticsLog.add("PROXY LISTENING: HTTPS port " + httpsPort);
            while (running) {
                Socket client = httpsServer.accept();
                executor.submit(() -> handleSslSocket(client, "", false));
            }
        } catch (Exception e) {
            httpsListening = false;
            if (running) { DiagnosticsLog.add("HTTPS LISTENER ERROR: " + e); Log.e(TAG, "HTTPS listener: " + e.getMessage()); }
        }
    }

    // ── Plain HTTP ────────────────────────────────────────────────────────────

    private void handleHttpClient(Socket client) {
        try {
            client.setSoTimeout(15000);
            InputStream raw = client.getInputStream();
            OutputStream out = client.getOutputStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(raw));
            String requestLine = reader.readLine();
            if (requestLine == null || requestLine.trim().isEmpty()) return;

            String[] parts = requestLine.split(" ");
            if (parts.length < 2) return;
            String method = parts[0];
            String rawUrl  = parts[1];

            Map<String, String> headers = readHeaders(reader);
            String hostHeader = headers.getOrDefault("host", "");

            if ("CONNECT".equalsIgnoreCase(method)) {
                // TLS tunnel: acknowledge, then upgrade socket to SSL
                handleConnect(client, out, rawUrl);
                return;
            }

            String fullUrl = rawUrl.startsWith("http") ? rawUrl : "http://" + hostHeader + rawUrl;
            processRequest(method, fullUrl, headers, reader, out);

        } catch (Exception e) {
            DiagnosticsLog.add("HTTP CLIENT ERROR: " + e);
            Log.e(TAG, "HTTP client: " + e.getMessage());
        } finally {
            try { client.close(); } catch (Exception ignored) {}
        }
    }

    // ── CONNECT (HTTP→HTTPS upgrade) ─────────────────────────────────────────

    private void handleConnect(Socket plainSocket, OutputStream rawOut, String hostPort) {
        try {
            // 1. Tell the client "tunnel is ready"
            rawOut.write("HTTP/1.1 200 Connection Established\r\n\r\n".getBytes("UTF-8"));
            rawOut.flush();

            // 2. Wrap plain socket with our TLS (the app gets our self-signed cert)
            SSLSocket ssl = (SSLSocket) serverSslContext.getSocketFactory()
                    .createSocket(plainSocket,
                            plainSocket.getInetAddress().getHostAddress(),
                            plainSocket.getPort(), true);
            ssl.setUseClientMode(false);
            ssl.startHandshake();

            String defaultHost = hostPort.contains(":") ? hostPort.split(":")[0] : hostPort;
            handleSslSocket(ssl, defaultHost, true);

        } catch (Exception e) {
            DiagnosticsLog.add("HTTPS CONNECT ERROR [" + hostPort + "]: " + e);
            Log.e(TAG, "CONNECT error [" + hostPort + "]: " + e.getMessage());
        } finally {
            try { plainSocket.close(); } catch (Exception ignored) {}
        }
    }

    // ── SSL socket handler (shared by CONNECT upgrade + direct HTTPS) ─────────

    private void handleSslSocket(Socket socket, String defaultHost, boolean fromConnect) {
        try {
            socket.setSoTimeout(15000);
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            OutputStream out = socket.getOutputStream();

            String requestLine = reader.readLine();
            if (requestLine == null || requestLine.trim().isEmpty()) return;

            String[] parts = requestLine.split(" ");
            if (parts.length < 2) return;
            String method = parts[0];
            String rawUrl  = parts[1];

            Map<String, String> headers = readHeaders(reader);
            String hostHeader = headers.getOrDefault("host", defaultHost);
            String fullUrl = "https://" + hostHeader + rawUrl;

            processRequest(method, fullUrl, headers, reader, out);

        } catch (Exception e) {
            DiagnosticsLog.add("HTTPS REQUEST ERROR: " + e);
            Log.e(TAG, "SSL socket error: " + e.getMessage());
        } finally {
            try { socket.close(); } catch (Exception ignored) {}
        }
    }

    // ── Core request processor ────────────────────────────────────────────────

    private void processRequest(String method, String fullUrl,
                                 Map<String, String> headers,
                                 BufferedReader reader,
                                 OutputStream out) throws IOException {
        // Log discovery (all URLs the target app touches)
        if (!discoveredUrls.contains(fullUrl)) {
            discoveredUrls.add(0, fullUrl);
            if (discoveredUrls.size() > 1000) discoveredUrls.remove(discoveredUrls.size() - 1);
        }

        DiagnosticsLog.add("REQUEST DETECTED: " + method + " " + fullUrl);
        InterceptRule matched = findRule(fullUrl);
        if (matched != null) {
            sendFakeResponse(out, matched);
            if (logCallback != null) logCallback.onLog(fullUrl, true, matched.fakeResponseCode);
        } else {
            // Read body if any (POST etc.)
            byte[] requestBody = new byte[0];
            String contentLenStr = headers.get("content-length");
            if (contentLenStr != null) {
                try {
                    int len = Integer.parseInt(contentLenStr.trim());
                    if (len > 0 && len < 10 * 1024 * 1024) {
                        requestBody = new byte[len];
                        DataInputStream dis = new DataInputStream(reader);
                        // BufferedReader already consumed headers; read body chars
                        char[] bodyChars = new char[len];
                        int read = reader.read(bodyChars, 0, len);
                        requestBody = new String(bodyChars, 0, Math.max(read, 0)).getBytes("UTF-8");
                    }
                } catch (Exception ignored) {}
            }
            forwardRequest(method, fullUrl, headers, requestBody, out);
            if (logCallback != null) logCallback.onLog(fullUrl, false, 200);
        }
    }

    // ── Rule matching ─────────────────────────────────────────────────────────

    private InterceptRule findRule(String url) {
        List<InterceptRule> snapshot = rules;
        for (InterceptRule rule : snapshot) {
            if (!rule.isEnabled) continue;
            boolean matched = false;
            switch (rule.matchType) {
                case "EXACT":
                    matched = url.equalsIgnoreCase(rule.urlPattern);
                    break;
                case "CONTAINS":
                    matched = url.toLowerCase().contains(rule.urlPattern.toLowerCase());
                    break;
                case "STARTS_WITH":
                    matched = url.toLowerCase().startsWith(rule.urlPattern.toLowerCase());
                    break;
                case "ENDS_WITH":
                    matched = url.toLowerCase().endsWith(rule.urlPattern.toLowerCase());
                    break;
                case "REGEX":
                    try { matched = url.matches("(?i).*" + rule.urlPattern + ".*"); }
                    catch (Exception ignored) {}
                    break;
            }
            if (matched) return rule;
        }
        return null;
    }

    // ── Fake response sender ──────────────────────────────────────────────────

    private void sendFakeResponse(OutputStream output, InterceptRule rule) throws Exception {
        byte[] body = rule.fakeResponseBody.getBytes("UTF-8");

        JSONObject headersJson;
        try {
            headersJson = new JSONObject(rule.fakeResponseHeaders);
        } catch (Exception e) {
            headersJson = new JSONObject();
            headersJson.put("Content-Type", "application/json");
        }

        StringBuilder sb = new StringBuilder();
        sb.append("HTTP/1.1 ").append(rule.fakeResponseCode).append(" OK\r\n");
        sb.append("Content-Length: ").append(body.length).append("\r\n");

        Iterator<String> keys = headersJson.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            sb.append(k).append(": ").append(headersJson.getString(k)).append("\r\n");
        }
        sb.append("Connection: close\r\n\r\n");

        output.write(sb.toString().getBytes("UTF-8"));
        output.write(body);
        output.flush();
    }

    // ── Forward to real server ────────────────────────────────────────────────

    private void forwardRequest(String method, String url,
                                 Map<String, String> headers,
                                 byte[] requestBody,
                                 OutputStream clientOut) {
        try {
            URL u = new URL(url);
            HttpURLConnection conn;

            if (url.startsWith("https")) {
                HttpsURLConnection sc = (HttpsURLConnection) u.openConnection();
                sc.setSSLSocketFactory(forwardSslFactory);
                sc.setHostnameVerifier((h, s) -> true);
                conn = sc;
            } else {
                conn = (HttpURLConnection) u.openConnection();
            }

            String safeMethod = method.equalsIgnoreCase("CONNECT") ? "GET" : method.toUpperCase();
            conn.setRequestMethod(safeMethod);
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setInstanceFollowRedirects(true);

            for (Map.Entry<String, String> e : headers.entrySet()) {
                try { conn.setRequestProperty(e.getKey(), e.getValue()); }
                catch (Exception ignored) {}
            }

            if (requestBody.length > 0 &&
                    (safeMethod.equals("POST") || safeMethod.equals("PUT") || safeMethod.equals("PATCH"))) {
                conn.setDoOutput(true);
                conn.getOutputStream().write(requestBody);
            }

            int code = conn.getResponseCode();
            byte[] responseBody;
            try {
                responseBody = readAll(conn.getInputStream());
            } catch (Exception e) {
                InputStream err = conn.getErrorStream();
                responseBody = err != null ? readAll(err) : new byte[0];
            }

            // Forward real response headers that matter
            StringBuilder sb = new StringBuilder();
            sb.append("HTTP/1.1 ").append(code).append(" OK\r\n");
            sb.append("Content-Length: ").append(responseBody.length).append("\r\n");
            String ct = conn.getContentType();
            if (ct != null) sb.append("Content-Type: ").append(ct).append("\r\n");
            sb.append("Connection: close\r\n\r\n");

            clientOut.write(sb.toString().getBytes("UTF-8"));
            clientOut.write(responseBody);
            clientOut.flush();

        } catch (Exception e) {
            try {
                byte[] errBody = ("{\"error\":\"proxy forward failed: "
                        + e.getMessage() + "\"}").getBytes("UTF-8");
                String resp = "HTTP/1.1 502 Bad Gateway\r\nContent-Length: "
                        + errBody.length + "\r\nConnection: close\r\n\r\n";
                clientOut.write(resp.getBytes());
                clientOut.write(errBody);
                clientOut.flush();
            } catch (Exception ignored) {}
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private Map<String, String> readHeaders(BufferedReader reader) throws IOException {
        Map<String, String> headers = new LinkedHashMap<>();
        String line;
        while ((line = reader.readLine()) != null && !line.isEmpty()) {
            int ci = line.indexOf(':');
            if (ci > 0) {
                String k = line.substring(0, ci).trim().toLowerCase();
                String v = line.substring(ci + 1).trim();
                headers.put(k, v);
            }
        }
        return headers;
    }

    private byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] tmp = new byte[4096];
        int n;
        while ((n = in.read(tmp)) != -1) buf.write(tmp, 0, n);
        return buf.toByteArray();
    }

    // ── TLS / Certificate helpers ─────────────────────────────────────────────

    private KeyPair generateRsaKeyPair() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048, new SecureRandom());
        return kpg.generateKeyPair();
    }

    /**
     * Build a self-signed X.509 cert using Android's internal sun.security.x509 APIs.
     * Works on rooted AOSP devices where the hidden API restriction doesn't apply.
     */
    @SuppressWarnings("unchecked")
    private X509Certificate buildSelfSignedCert(KeyPair kp) throws Exception {
        try {
            Class<?> x500NameClass  = Class.forName("sun.security.x509.X500Name");
            Class<?> certInfoClass  = Class.forName("sun.security.x509.X509CertInfo");
            Class<?> certImplClass  = Class.forName("sun.security.x509.X509CertImpl");
            Class<?> algIdClass     = Class.forName("sun.security.x509.AlgorithmId");
            Class<?> validityClass  = Class.forName("sun.security.x509.CertificateValidity");
            Class<?> snClass        = Class.forName("sun.security.x509.CertificateSerialNumber");
            Class<?> algIdFieldClass= Class.forName("sun.security.x509.CertificateAlgorithmId");
            Class<?> subjectClass   = Class.forName("sun.security.x509.CertificateSubjectName");
            Class<?> issuerClass    = Class.forName("sun.security.x509.CertificateIssuerName");
            Class<?> keyClass       = Class.forName("sun.security.x509.CertificateX509Key");

            Object x500Name = x500NameClass.getConstructor(String.class)
                    .newInstance("CN=NetInterceptorCA,O=Proxy,C=US");
            java.util.Date from = new java.util.Date();
            java.util.Date to   = new java.util.Date(from.getTime() + 10L * 365 * 24 * 60 * 60 * 1000);
            Object validity  = validityClass.getConstructor(java.util.Date.class, java.util.Date.class)
                    .newInstance(from, to);
            Object sn        = snClass.getConstructor(BigInteger.class)
                    .newInstance(BigInteger.valueOf(System.currentTimeMillis()));
            Object algId     = algIdClass.getMethod("get", String.class).invoke(null, "SHA256withRSA");
            Object algIdField= algIdFieldClass.getConstructor(algId.getClass()).newInstance(algId);

            Object info = certInfoClass.newInstance();
            java.lang.reflect.Method set = certInfoClass.getMethod("set", String.class, Object.class);
            set.invoke(info, "validity",     validity);
            set.invoke(info, "serialNumber", sn);
            set.invoke(info, "subject",   subjectClass.getConstructor(x500NameClass).newInstance(x500Name));
            set.invoke(info, "issuer",    issuerClass.getConstructor(x500NameClass).newInstance(x500Name));
            set.invoke(info, "key",       keyClass.getConstructor(PublicKey.class).newInstance(kp.getPublic()));
            set.invoke(info, "algorithmID", algIdField);

            Object cert = certImplClass.getConstructor(certInfoClass).newInstance(info);
            certImplClass.getMethod("sign", PrivateKey.class, String.class)
                         .invoke(cert, kp.getPrivate(), "SHA256withRSA");

            return (X509Certificate) cert;

        } catch (Exception e) {
            Log.e(TAG, "Cert gen via reflection failed: " + e.getMessage());
            throw e;
        }
    }

    private SSLContext buildServerContext(KeyPair kp, X509Certificate cert) throws Exception {
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(null, null);
        ks.setKeyEntry("proxy", kp.getPrivate(), new char[0],
                new java.security.cert.Certificate[]{cert});

        KeyManagerFactory kmf = KeyManagerFactory.getInstance(
                KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(ks, new char[0]);

        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(kmf.getKeyManagers(), buildTrustAllManagers(), new SecureRandom());
        return ctx;
    }

    private SSLSocketFactory buildTrustAllFactory() throws Exception {
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, buildTrustAllManagers(), new SecureRandom());
        return ctx.getSocketFactory();
    }

    private TrustManager[] buildTrustAllManagers() {
        return new TrustManager[]{
            new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] c, String a) {}
                public void checkServerTrusted(X509Certificate[] c, String a) {}
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            }
        };
    }
}
