package com.netinterceptor.ui;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.net.VpnService;
import android.os.Build;
import androidx.lifecycle.*;
import com.netinterceptor.data.model.TargetApp;
import com.netinterceptor.data.repository.AppDatabase;
import com.netinterceptor.service.InterceptorService;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainViewModel extends AndroidViewModel {

    private final AppDatabase    db;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    // VPN does not need root; we keep this LiveData so the UI compiles,
    // but always post true (VPN is available on every Android device).
    private final MutableLiveData<Boolean> rootedLive = new MutableLiveData<>();

    public MainViewModel(Application app) {
        super(app);
        db = AppDatabase.getInstance(app);
        // VpnService is always available — no root check needed
        rootedLive.postValue(true);
    }

    public LiveData<List<TargetApp>> getAllApps() {
        return db.targetAppDao().getAllApps();
    }

    public LiveData<Boolean> isRooted() { return rootedLive; }

    public void addApp(String pkg, String label) {
        executor.submit(() -> db.targetAppDao().insertApp(new TargetApp(pkg, label)));
    }

    public void toggleApp(TargetApp app) {
        executor.submit(() -> {
            app.isEnabled = !app.isEnabled;
            db.targetAppDao().updateApp(app);
            reloadService();
        });
    }

    public void deleteApp(TargetApp app) {
        executor.submit(() -> {
            db.interceptRuleDao().deleteRulesForApp(app.id);
            db.targetAppDao().deleteApp(app);
            reloadService();
        });
    }

    /**
     * Start VPN service.
     * IMPORTANT: caller (MainActivity) must call VpnService.prepare() first
     * and handle the permission intent before calling this.
     */
    public void startService(Context ctx) {
        Intent intent = new Intent(ctx, InterceptorService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(intent);
        } else {
            ctx.startService(intent);
        }
    }

    public void stopService(Context ctx) {
        Intent intent = new Intent(ctx, InterceptorService.class);
        intent.setAction("STOP");
        ctx.startService(intent);
    }

    private void reloadService() {
        if (InterceptorService.instance != null) {
            InterceptorService.instance.reloadRules();
        }
    }

    public List<String[]> getInstalledApps(Context ctx) {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = ctx.getPackageManager().queryIntentActivities(intent, 0);
        List<String[]> result = new ArrayList<>();
        for (ResolveInfo ri : list) {
            String pkg   = ri.activityInfo.packageName;
            String label = ri.loadLabel(ctx.getPackageManager()).toString();
            result.add(new String[]{pkg, label});
        }
        result.sort((a, b) -> a[1].compareToIgnoreCase(b[1]));
        return result;
    }
}
