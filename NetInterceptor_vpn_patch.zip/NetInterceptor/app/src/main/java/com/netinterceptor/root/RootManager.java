package com.netinterceptor.root;

/**
 * RootManager is kept for backward compatibility but is no longer used
 * by the VpnService-based interceptor. All traffic routing is now handled
 * through Android's VpnService API, which requires no root access.
 *
 * This stub prevents compilation errors from any residual references.
 */
public class RootManager {

    public static boolean isRooted() {
        // VPN approach doesn't need root
        return true;
    }
}
