package com.netinterceptor.ui;

import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.netinterceptor.R;
import com.netinterceptor.data.model.TargetApp;
import com.netinterceptor.service.InterceptorService;
import com.netinterceptor.ui.adapter.TargetAppAdapter;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private MainViewModel     viewModel;
    private TargetAppAdapter  adapter;
    private Switch            switchService;
    private TextView          tvStatus, tvRootStatus;

    // VPN permission result launcher
    private final ActivityResultLauncher<Intent> vpnPermLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK) {
                            // User granted VPN permission — now start service
                            viewModel.startService(this);
                        } else {
                            // User denied — revert switch
                            switchService.setChecked(false);
                            Toast.makeText(this,
                                    "VPN permission required to intercept traffic",
                                    Toast.LENGTH_LONG).show();
                        }
                    });

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewModel = new ViewModelProvider(this).get(MainViewModel.class);

        switchService = findViewById(R.id.switch_service);
        tvStatus      = findViewById(R.id.tv_status);
        tvRootStatus  = findViewById(R.id.tv_root_status);
        RecyclerView rv  = findViewById(R.id.rv_apps);
        FloatingActionButton fab = findViewById(R.id.fab_add);
        TextView tvLogs = findViewById(R.id.tv_logs);

        adapter = new TargetAppAdapter(
                this::showAppOptions,
                app -> viewModel.toggleApp(app),
                this::confirmDelete
        );
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        viewModel.getAllApps().observe(this, apps -> {
            adapter.setApps(apps);
            tvStatus.setText(apps.size() + " app(s) targeted");
        });

        // isRooted() now always returns true (VPN doesn't need root)
        viewModel.isRooted().observe(this, ok -> {
            tvRootStatus.setText("VPN: Ready ✓");
            tvRootStatus.setTextColor(0xFF00E676);
        });

        switchService.setChecked(InterceptorService.isRunning);
        switchService.setOnCheckedChangeListener((btn, checked) -> {
            if (checked) startVpnWithPermission();
            else         viewModel.stopService(this);
        });

        fab.setOnClickListener(v -> showAddDialog());
        tvLogs.setOnClickListener(v -> startActivity(new Intent(this, LogsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        switchService.setChecked(InterceptorService.isRunning);
    }

    // ── VPN permission flow ───────────────────────────────────────────────────

    /**
     * Android requires explicit user consent before a VPN can run.
     * VpnService.prepare() returns null if permission was already granted,
     * or an Intent to show the system consent dialog.
     */
    private void startVpnWithPermission() {
        Intent prepareIntent = VpnService.prepare(this);
        if (prepareIntent == null) {
            // Already have permission — start directly
            viewModel.startService(this);
        } else {
            // Show system dialog; result handled in vpnPermLauncher
            vpnPermLauncher.launch(prepareIntent);
        }
    }

    // ── App option dialog ─────────────────────────────────────────────────────

    private void showAppOptions(TargetApp app) {
        String[] options = {"Manage Rules", "Discover APIs (sniff)"};
        new AlertDialog.Builder(this)
                .setTitle(app.appLabel)
                .setItems(options, (d, which) -> {
                    if (which == 0) {
                        Intent intent = new Intent(this, RulesActivity.class);
                        intent.putExtra("app_id",    app.id);
                        intent.putExtra("app_label", app.appLabel);
                        intent.putExtra("pkg",       app.packageName);
                        startActivity(intent);
                    } else {
                        if (!InterceptorService.isRunning) {
                            Toast.makeText(this,
                                    "Start the interceptor first (toggle ON)",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Intent intent = new Intent(this, DiscoverActivity.class);
                        intent.putExtra("app_id",    app.id);
                        intent.putExtra("app_label", app.appLabel);
                        startActivity(intent);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Add app dialog ────────────────────────────────────────────────────────

    private void showAddDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_app, null);
        EditText etSearch  = dialogView.findViewById(R.id.et_search);
        ListView listView  = dialogView.findViewById(R.id.lv_apps);
        EditText etManual  = dialogView.findViewById(R.id.et_manual_pkg);
        Button   btnManual = dialogView.findViewById(R.id.btn_manual);

        java.util.List<String[]> installed = viewModel.getInstalledApps(this);
        String[] labels = installed.stream()
                .map(a -> a[1] + "\n" + a[0])
                .toArray(String[]::new);
        ArrayAdapter<String> listAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, labels);
        listView.setAdapter(listAdapter);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Add Target App")
                .setView(dialogView)
                .setNegativeButton("Cancel", null)
                .create();

        listView.setOnItemClickListener((parent, view, pos, id) -> {
            viewModel.addApp(installed.get(pos)[0], installed.get(pos)[1]);
            dialog.dismiss();
            // If VPN is running, restart to include new package
            if (InterceptorService.isRunning) {
                viewModel.stopService(this);
                switchService.postDelayed(() -> {
                    switchService.setChecked(true);
                    startVpnWithPermission();
                }, 500);
            }
        });

        etSearch.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                listAdapter.getFilter().filter(s);
            }
            public void afterTextChanged(android.text.Editable e) {}
        });

        btnManual.setOnClickListener(v -> {
            String pkg = etManual.getText().toString().trim();
            if (!pkg.isEmpty()) {
                viewModel.addApp(pkg, pkg);
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    // ── Delete confirmation ───────────────────────────────────────────────────

    private void confirmDelete(TargetApp app) {
        new AlertDialog.Builder(this)
                .setTitle("Delete " + app.appLabel + "?")
                .setMessage("All rules will also be deleted.")
                .setPositiveButton("Delete", (d, w) -> viewModel.deleteApp(app))
                .setNegativeButton("Cancel", null)
                .show();
    }
}
