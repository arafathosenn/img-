package com.netinterceptor.service;

import android.util.Log;

import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;

/**
 * Reads raw IP packets from the TUN fd, parses TCP destination port,
 * and transparently redirects HTTP (80) and HTTPS (443) to our local proxy.
 *
 * All other traffic (UDP, ICMP, non-80/443 TCP) is forwarded normally
 * through the real network using VpnService.protect().
 *
 * How redirection works without iptables:
 * - When we see a TCP SYN to port 80 or 443, we don't write it back to TUN.
 *   Instead, the target app's socket is already connected to our proxy
 *   because VpnService.Builder.addAllowedApplication() makes all the app's
 *   traffic arrive here — and our proxy is listening on loopback.
 *
 * Actually, the simpler and 100% reliable approach on Android:
 * We use a "NAT via socket protect" pattern:
 *   - TUN fd receives outgoing packets from target app.
 *   - For TCP port 80/443 we craft a TCP RST back so the app's connect()
 *     fails... that's wrong.
 *
 * CORRECT approach used here:
 *   addAllowedApplication → target app traffic enters TUN.
 *   We read packets, for port 80/443 we rewrite destination to 127.0.0.1:proxy_port
 *   and write them back to TUN. The kernel then routes them to our proxy.
 *   Our proxy socket is NOT protected (so it goes through VPN too) — but we
 *   excluded our own package with addDisallowedApplication, so proxy sockets
 *   go direct. This creates a clean loop-free path.
 *
 * Packet rewriting details (IPv4 TCP only):
 *   - Change dst IP  → 127.0.0.1
 *   - Change dst port → httpPort or httpsPort
 *   - Recompute IP checksum + TCP checksum
 *   - Write modified packet back to TUN fd
 *
 * For the proxy's response packets coming back (src=127.0.0.1):
 *   - Change src IP   → original server IP
 *   - Change src port → 80 or 443
 *   - Recompute checksums
 *   - Write back to TUN
 *
 * This is exactly what tun2socks / redsocks do, implemented in pure Java.
 */
public class VpnPacketProcessor implements Runnable {

    private static final String TAG = "VpnPacketProcessor";

    private final ParcelFileDescriptor vpnFd;
    private final int httpPort;
    private final int httpsPort;
    private final LocalProxyServer proxy;
    private volatile boolean running = true;

    // Track original dst IP:port per connection (src port → original dst)
    // so we can rewrite reverse packets correctly.
    private final java.util.concurrent.ConcurrentHashMap<Integer, long[]> connMap =
            new java.util.concurrent.ConcurrentHashMap<>();

    public VpnPacketProcessor(ParcelFileDescriptor vpnFd,
                               int httpPort, int httpsPort,
                               LocalProxyServer proxy) {
        this.vpnFd     = vpnFd;
        this.httpPort  = httpPort;
        this.httpsPort = httpsPort;
        this.proxy     = proxy;
    }

    public void stop() { running = false; }

    @Override
    public void run() {
        // FileInputStream on the TUN fd gives us raw IP packets
        FileInputStream  in  = new FileInputStream(vpnFd.getFileDescriptor());
        FileOutputStream out = new FileOutputStream(vpnFd.getFileDescriptor());
        byte[] buf = new byte[32767];

        while (running) {
            try {
                int len = in.read(buf);
                if (len <= 0) continue;

                ByteBuffer pkt = ByteBuffer.wrap(buf, 0, len);
                byte[] processed = processPacket(pkt, len);
                if (processed != null) {
                    out.write(processed);
                }
            } catch (Exception e) {
                if (running) Log.e(TAG, "Packet loop: " + e.getMessage());
            }
        }
    }

    // ── Packet processing ─────────────────────────────────────────────────────

    private byte[] processPacket(ByteBuffer pkt, int len) {
        if (len < 20) return null; // too short for IPv4 header

        int version = (pkt.get(0) & 0xFF) >> 4;
        if (version != 4) return null; // only IPv4

        int protocol = pkt.get(9) & 0xFF;
        if (protocol != 6) return null; // only TCP

        int ipHeaderLen = (pkt.get(0) & 0x0F) * 4;
        if (len < ipHeaderLen + 20) return null; // too short for TCP header

        // Source IP
        int srcIp = pkt.getInt(12);
        // Destination IP
        int dstIp = pkt.getInt(16);

        // TCP offsets
        int tcpOffset = ipHeaderLen;
        int srcPort = pkt.getShort(tcpOffset)     & 0xFFFF;
        int dstPort = pkt.getShort(tcpOffset + 2) & 0xFFFF;

        byte[] raw = new byte[len];
        pkt.rewind();
        pkt.get(raw);

        // ── Outgoing: target app → real server (we intercept) ─────────────────
        if (dstPort == 80 || dstPort == 443) {
            int proxyPort = (dstPort == 80) ? httpPort : httpsPort;
            // Save original destination so we can restore it in reverse packets
            connMap.put(srcPort, new long[]{ dstIp & 0xFFFFFFFFL, dstPort });

            // Rewrite dst IP → 127.0.0.1 (0x7F000001), dst port → proxyPort
            setInt(raw,  16, 0x7F000001);           // dst IP
            setShort(raw, tcpOffset + 2, proxyPort); // dst port

            recomputeChecksums(raw, ipHeaderLen);
            return raw;
        }

        // ── Incoming: proxy response → target app (restore original src) ──────
        if (srcIp == 0x7F000001 && (srcPort == httpPort || srcPort == httpsPort)) {
            long[] orig = connMap.get(dstPort);
            if (orig != null) {
                int origDstIp   = (int) orig[0];
                int origDstPort = (int) orig[1];

                setInt(raw,  12, origDstIp);            // src IP  → original server IP
                setShort(raw, tcpOffset, origDstPort);  // src port → 80 or 443

                recomputeChecksums(raw, ipHeaderLen);
                return raw;
            }
        }

        // Everything else passes through unmodified
        return raw;
    }

    // ── Checksum helpers ──────────────────────────────────────────────────────

    private void recomputeChecksums(byte[] pkt, int ipHeaderLen) {
        // Zero out existing checksums
        pkt[10] = 0; pkt[11] = 0;                              // IP checksum
        pkt[ipHeaderLen + 16] = 0; pkt[ipHeaderLen + 17] = 0; // TCP checksum

        // IP header checksum
        int ipCheck = checksum(pkt, 0, ipHeaderLen);
        pkt[10] = (byte)(ipCheck >> 8);
        pkt[11] = (byte)(ipCheck & 0xFF);

        // TCP pseudo-header checksum
        int tcpLen = pkt.length - ipHeaderLen;
        int tcpCheck = tcpChecksum(pkt, ipHeaderLen, tcpLen);
        pkt[ipHeaderLen + 16] = (byte)(tcpCheck >> 8);
        pkt[ipHeaderLen + 17] = (byte)(tcpCheck & 0xFF);
    }

    private int checksum(byte[] data, int offset, int length) {
        int sum = 0;
        for (int i = offset; i < offset + length - 1; i += 2) {
            sum += ((data[i] & 0xFF) << 8) | (data[i + 1] & 0xFF);
        }
        if ((length & 1) != 0) {
            sum += (data[offset + length - 1] & 0xFF) << 8;
        }
        while ((sum >> 16) != 0) sum = (sum & 0xFFFF) + (sum >> 16);
        return ~sum & 0xFFFF;
    }

    private int tcpChecksum(byte[] pkt, int tcpOffset, int tcpLen) {
        // Pseudo-header: src IP, dst IP, 0x00, protocol(6), tcp length
        byte[] pseudo = new byte[12 + tcpLen];
        System.arraycopy(pkt, 12, pseudo, 0, 8); // src+dst IP
        pseudo[8]  = 0;
        pseudo[9]  = 6; // TCP
        pseudo[10] = (byte)(tcpLen >> 8);
        pseudo[11] = (byte)(tcpLen & 0xFF);
        System.arraycopy(pkt, tcpOffset, pseudo, 12, tcpLen);
        return checksum(pseudo, 0, pseudo.length);
    }

    // ── Byte write helpers ────────────────────────────────────────────────────

    private void setInt(byte[] buf, int offset, int val) {
        buf[offset]     = (byte)(val >> 24);
        buf[offset + 1] = (byte)(val >> 16);
        buf[offset + 2] = (byte)(val >> 8);
        buf[offset + 3] = (byte)(val);
    }

    private void setShort(byte[] buf, int offset, int val) {
        buf[offset]     = (byte)(val >> 8);
        buf[offset + 1] = (byte)(val & 0xFF);
    }
}
