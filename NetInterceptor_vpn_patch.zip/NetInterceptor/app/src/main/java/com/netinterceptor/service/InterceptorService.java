package com.netinterceptor.service;

import android.app.*;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.VpnService;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.netinterceptor.R;
import com.netinterceptor.data.model.InterceptRule;
import com.netinterceptor.data.model.TargetApp;
import com.netinterceptor.data.repository.AppDatabase;
import com.netinterceptor.ui.MainActivity;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;

public class InterceptorService extends VpnService {

    private static final String TAG        = "InterceptorService";
    private static final int    NOTIF_ID   = 1;
    private static final String CHANNEL_ID = "interceptor_ch";

    // Proxy ports — only used internally on loopback
    public static final int HTTP_PORT  = 18080;
    public static final int HTTPS_PORT = 18081;

    // Static handles for UI access
    public static InterceptorService instance  = null;
    public static boolean             isRunning = false;

    public final List<String> logs = Collections.synchronizedList(new ArrayList<>());

    private LocalProxyServer      proxy;
    private ParcelFileDescriptor  vpnInterface;
    private final ExecutorService executor = Executors.newCachedThreadPool();

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        proxy = new LocalProxyServer(HTTP_PORT, HTTPS_PORT, (url, intercepted, code) -> {
            String entry = (intercepted ? "[INTERCEPT] " : "[PASS] ") + code + " " + url;
            logs.add(0, entry);
            if (logs.size() > 500) logs.remove(logs.size() - 1);
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForegroundNotif();
        executor.submit(this::startVpn);
        isRunning = true;
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        instance  = null;
        stopVpn();
        executor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        // VpnService also handles onBind; delegate properly
        return super.onBind(intent);
    }

    // ── Core: build VPN + start proxy ─────────────────────────────────────────

    private void startVpn() {
        try {
            // 1. Load rules & apps from DB
            reloadRules();

            // 2. Start the local MITM proxy first
            proxy.start();

            // 3. Build the VPN interface restricted to target packages
            vpnInterface = buildVpnInterface();
            if (vpnInterface == null) {
                Log.e(TAG, "VPN interface could not be created");
                return;
            }

            // 4. Start packet processor (reads TUN, routes to proxy)
            VpnPacketProcessor processor = new VpnPacketProcessor(
                    vpnInterface, HTTP_PORT, HTTPS_PORT, proxy);
            executor.submit(processor);

            Log.d(TAG, "VPN started OK");
        } catch (Exception e) {
            Log.e(TAG, "startVpn error: " + e.getMessage());
        }
    }

    private void stopVpn() {
        if (proxy != null) proxy.stop();
        if (vpnInterface != null) {
            try { vpnInterface.close(); } catch (IOException ignored) {}
            vpnInterface = null;
        }
    }

    // ── VPN interface builder ─────────────────────────────────────────────────

    private ParcelFileDescriptor buildVpnInterface() {
        AppDatabase db   = AppDatabase.getInstance(this);
        List<TargetApp> apps = db.targetAppDao().getEnabledApps();

        Builder builder = new Builder();
        builder.setSession("NetInterceptor");

        // Virtual subnet — just needs to exist, we intercept at proxy level
        builder.addAddress("10.0.0.1", 32);
        builder.addRoute("0.0.0.0", 0);            // capture all IPv4 traffic
        builder.addDnsServer("8.8.8.8");
        builder.setMtu(1500);
        builder.setBlocking(true);

        // KEY: only route traffic from target packages through the VPN.
        // All other apps bypass completely — normal internet, no overhead.
        boolean anyAdded = false;
        for (TargetApp app : apps) {
            try {
                builder.addAllowedApplication(app.packageName);
                anyAdded = true;
                Log.d(TAG, "VPN allows: " + app.packageName);
            } catch (Exception e) {
                Log.w(TAG, "Cannot add " + app.packageName + ": " + e.getMessage());
            }
        }

        if (!anyAdded) {
            Log.w(TAG, "No target apps added — VPN would capture nothing, aborting");
            return null;
        }

        // Exclude ourselves so we don't loop proxy traffic back through VPN
        try { builder.addDisallowedApplication(getPackageName()); }
        catch (Exception ignored) {}

        try {
            return builder.establish();
        } catch (Exception e) {
            Log.e(TAG, "establish() failed: " + e.getMessage());
            return null;
        }
    }

    // ── Rules ─────────────────────────────────────────────────────────────────

    public void reloadRules() {
        AppDatabase db   = AppDatabase.getInstance(this);
        List<TargetApp> apps = db.targetAppDao().getEnabledApps();
        List<InterceptRule> all = new ArrayList<>();
        for (TargetApp app : apps) {
            all.addAll(db.interceptRuleDao().getEnabledRulesForApp(app.id));
        }
        if (proxy != null) proxy.rules = all;
        Log.d(TAG, "Rules loaded: " + all.size());
    }

    // ── Discover passthrough ──────────────────────────────────────────────────

    public List<String> getDiscoveredUrls() {
        if (proxy != null) return new ArrayList<>(proxy.discoveredUrls);
        return new ArrayList<>();
    }

    public void clearDiscoveredUrls() {
        if (proxy != null) proxy.discoveredUrls.clear();
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private void startForegroundNotif() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Interceptor", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);

        Intent stopIntent = new Intent(this, InterceptorService.class);
        stopIntent.setAction("STOP");
        PendingIntent stopPi = PendingIntent.getService(
                this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(
                this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE);

        Notification notif = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("NetInterceptor Active")
                .setContentText("Intercepting target app traffic")
                .setSmallIcon(R.drawable.ic_shield)
                .setContentIntent(openPi)
                .addAction(0, "Stop", stopPi)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIF_ID, notif);
        }
    }
}
