package com.netinterceptor.service;

import android.util.Log;
import com.netinterceptor.data.model.InterceptRule;
import org.json.JSONObject;

import java.io.*;
import java.math.BigInteger;
import java.net.*;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.concurrent.*;
import javax.net.ssl.*;

/**
 * Local MITM proxy. Listens on:
 *   127.0.0.1:httpPort  → plain HTTP intercept
 *   127.0.0.1:httpsPort → TLS MITM intercept
 *
 * Target app traffic arrives here because VpnPacketProcessor rewrites
 * TCP dst to 127.0.0.1:proxy_port.
 *
 * For HTTPS the app sends a CONNECT request (or raw TLS ClientHello).
 * We terminate TLS with our self-signed cert, read the HTTP request,
 * apply intercept rules, and either return a fake response or forward
 * to the real server.
 *
 * Because the target app has no SSL pinning, it accepts our cert.
 *
 * All non-matched URLs are forwarded transparently to the real server
 * via a protected socket (VpnService.protect is NOT needed here because
 * we excluded our own package from the VPN — our sockets go direct).
 */
public class LocalProxyServer {

    private static final String TAG = "LocalProxyServer";

    private final int httpPort;
    private final int httpsPort;
    private volatile boolean running = false;

    private ServerSocket httpServer;
    private ServerSocket httpsServer;

    private final ExecutorService executor = Executors.newCachedThreadPool();

    public volatile List<InterceptRule> rules = new ArrayList<>();
    public final List<String> discoveredUrls  =
            Collections.synchronizedList(new ArrayList<>());

    public interface LogCallback {
        void onLog(String url, boolean intercepted, int code);
    }

    private final LogCallback logCallback;
    private SSLContext serverSslContext;
    private SSLSocketFactory trustAllFactory;

    // ── Constructor ───────────────────────────────────────────────────────────

    public LocalProxyServer(int httpPort, int httpsPort, LogCallback logCallback) {
        this.httpPort    = httpPort;
        this.httpsPort   = httpsPort;
        this.logCallback = logCallback;
        try {
            KeyPair kp   = generateRsaKeyPair();
            X509Certificate cert = buildSelfSignedCert(kp);
            serverSslContext = buildServerContext(kp, cert);
            trustAllFactory  = buildTrustAllFactory();
        } catch (Exception e) {
            Log.e(TAG, "SSL init: " + e.getMessage());
        }
    }

    // ── Start / Stop ──────────────────────────────────────────────────────────

    public void start() {
        running = true;
        executor.submit(this::runHttpListener);
        executor.submit(this::runHttpsListener);
        Log.d(TAG, "Proxy started HTTP=" + httpPort + " HTTPS=" + httpsPort);
    }

    public void stop() {
        running = false;
        try { if (httpServer  != null) httpServer.close();  } catch (Exception ignored) {}
        try { if (httpsServer != null) httpsServer.close(); } catch (Exception ignored) {}
        executor.shutdownNow();
    }

    // ── Listeners ─────────────────────────────────────────────────────────────

    private void runHttpListener() {
        try {
            httpServer = new ServerSocket();
            httpServer.setReuseAddress(true);
            httpServer.bind(new InetSocketAddress("127.0.0.1", httpPort));
            while (running) {
                Socket client = httpServer.accept();
                executor.submit(() -> handleClient(client, false));
            }
        } catch (Exception e) {
            if (running) Log.e(TAG, "HTTP listener: " + e.getMessage());
        }
    }

    private void runHttpsListener() {
        try {
            if (serverSslContext == null) return;
            SSLServerSocketFactory ssf = serverSslContext.getServerSocketFactory();
            SSLServerSocket sss = (SSLServerSocket) ssf.createServerSocket();
            sss.setReuseAddress(true);
            sss.bind(new InetSocketAddress("127.0.0.1", httpsPort));
            httpsServer = sss;
            while (running) {
                Socket client = httpsServer.accept();
                executor.submit(() -> handleClient(client, true));
            }
        } catch (Exception e) {
            if (running) Log.e(TAG, "HTTPS listener: " + e.getMessage());
        }
    }

    // ── Client handler ────────────────────────────────────────────────────────

    private void handleClient(Socket client, boolean isTls) {
        try {
            client.setSoTimeout(15_000);

            if (isTls) {
                // TLS connection: could be CONNECT tunnel or direct TLS
                handleTlsClient(client);
            } else {
                handlePlainClient(client);
            }
        } catch (Exception e) {
            Log.d(TAG, "client error: " + e.getMessage());
        } finally {
            try { client.close(); } catch (Exception ignored) {}
        }
    }

    // ── Plain HTTP ────────────────────────────────────────────────────────────

    private void handlePlainClient(Socket client) throws Exception {
        InputStream  rawIn = client.getInputStream();
        OutputStream out   = client.getOutputStream();

        // We need to peek the first line to detect CONNECT
        BufferedReader reader = new BufferedReader(new InputStreamReader(rawIn, "UTF-8"));
        String requestLine = reader.readLine();
        if (requestLine == null || requestLine.isEmpty()) return;

        String[] parts = requestLine.split(" ", 3);
        if (parts.length < 2) return;

        String method = parts[0];
        String rawUrl  = parts[1];
        Map<String, String> headers = readHeaders(reader);
        String host = headers.getOrDefault("host", "");

        if ("CONNECT".equalsIgnoreCase(method)) {
            // Upgrade to TLS MITM
            out.write("HTTP/1.1 200 Connection Established\r\n\r\n".getBytes("UTF-8"));
            out.flush();
            handleConnectUpgrade(client, out, rawUrl);
            return;
        }

        String fullUrl = rawUrl.startsWith("http") ? rawUrl : "http://" + host + rawUrl;
        byte[] body = readBody(headers, reader);
        processAndRespond(method, fullUrl, headers, body, out);
    }

    // ── CONNECT upgrade → TLS MITM ────────────────────────────────────────────

    private void handleConnectUpgrade(Socket plainSocket, OutputStream rawOut, String hostPort) {
        try {
            SSLSocket ssl = (SSLSocket) serverSslContext.getSocketFactory()
                    .createSocket(plainSocket,
                            plainSocket.getInetAddress().getHostAddress(),
                            plainSocket.getPort(), true);
            ssl.setUseClientMode(false);
            ssl.startHandshake();

            // Now read HTTP inside the TLS tunnel
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(ssl.getInputStream(), "UTF-8"));
            OutputStream sslOut = ssl.getOutputStream();

            String requestLine = reader.readLine();
            if (requestLine == null || requestLine.isEmpty()) return;

            String[] parts = requestLine.split(" ", 3);
            if (parts.length < 2) return;

            String method  = parts[0];
            String rawPath = parts[1];
            Map<String, String> headers = readHeaders(reader);

            String host = headers.getOrDefault("host",
                    hostPort.contains(":") ? hostPort.split(":")[0] : hostPort);
            String fullUrl = "https://" + host + rawPath;

            byte[] body = readBody(headers, reader);
            processAndRespond(method, fullUrl, headers, body, sslOut);

        } catch (Exception e) {
            Log.d(TAG, "CONNECT upgrade error [" + hostPort + "]: " + e.getMessage());
        }
    }

    // ── TLS client (direct — when target sends raw TLS without CONNECT) ───────

    private void handleTlsClient(Socket rawClient) throws Exception {
        // We're already the TLS server; wrap the socket
        SSLSocket ssl = (SSLSocket) serverSslContext.getSocketFactory()
                .createSocket(rawClient,
                        rawClient.getInetAddress().getHostAddress(),
                        rawClient.getPort(), true);
        ssl.setUseClientMode(false);
        ssl.startHandshake();

        BufferedReader reader = new BufferedReader(
                new InputStreamReader(ssl.getInputStream(), "UTF-8"));
        OutputStream out = ssl.getOutputStream();

        String requestLine = reader.readLine();
        if (requestLine == null || requestLine.isEmpty()) return;

        String[] parts = requestLine.split(" ", 3);
        if (parts.length < 2) return;

        String method  = parts[0];
        String rawPath = parts[1];
        Map<String, String> headers = readHeaders(reader);
        String host    = headers.getOrDefault("host", "");
        String fullUrl = "https://" + host + rawPath;

        byte[] body = readBody(headers, reader);
        processAndRespond(method, fullUrl, headers, body, out);
    }

    // ── Core: match rules → fake or forward ───────────────────────────────────

    private void processAndRespond(String method, String fullUrl,
                                    Map<String, String> headers,
                                    byte[] body,
                                    OutputStream out) throws IOException {
        // Log discovery
        if (!discoveredUrls.contains(fullUrl)) {
            discoveredUrls.add(0, fullUrl);
            if (discoveredUrls.size() > 1000) discoveredUrls.remove(discoveredUrls.size() - 1);
        }

        InterceptRule matched = findRule(fullUrl);
        if (matched != null) {
            sendFakeResponse(out, matched);
            if (logCallback != null) logCallback.onLog(fullUrl, true, matched.fakeResponseCode);
        } else {
            forwardRequest(method, fullUrl, headers, body, out);
            if (logCallback != null) logCallback.onLog(fullUrl, false, 0);
        }
    }

    // ── Rule matching ─────────────────────────────────────────────────────────

    private InterceptRule findRule(String url) {
        List<InterceptRule> snap = rules;
        for (InterceptRule r : snap) {
            if (!r.isEnabled) continue;
            boolean m = false;
            switch (r.matchType) {
                case "EXACT":
                    m = url.equalsIgnoreCase(r.urlPattern);
                    break;
                case "CONTAINS":
                    m = url.toLowerCase().contains(r.urlPattern.toLowerCase());
                    break;
                case "STARTS_WITH":
                    m = url.toLowerCase().startsWith(r.urlPattern.toLowerCase());
                    break;
                case "ENDS_WITH":
                    m = url.toLowerCase().endsWith(r.urlPattern.toLowerCase());
                    break;
                case "REGEX":
                    try { m = url.matches("(?i)" + r.urlPattern); }
                    catch (Exception ignored) {}
                    break;
            }
            if (m) return r;
        }
        return null;
    }

    // ── Fake response ─────────────────────────────────────────────────────────

    private void sendFakeResponse(OutputStream out, InterceptRule rule) throws Exception {
        byte[] body = rule.fakeResponseBody != null
                ? rule.fakeResponseBody.getBytes("UTF-8") : new byte[0];

        JSONObject hdrs;
        try { hdrs = new JSONObject(rule.fakeResponseHeaders); }
        catch (Exception e) {
            hdrs = new JSONObject();
            hdrs.put("Content-Type", "application/json");
        }

        StringBuilder sb = new StringBuilder();
        sb.append("HTTP/1.1 ").append(rule.fakeResponseCode).append(" OK\r\n");
        sb.append("Content-Length: ").append(body.length).append("\r\n");
        Iterator<String> keys = hdrs.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            sb.append(k).append(": ").append(hdrs.getString(k)).append("\r\n");
        }
        sb.append("Connection: close\r\n\r\n");

        out.write(sb.toString().getBytes("UTF-8"));
        out.write(body);
        out.flush();
    }

    // ── Forward to real server ────────────────────────────────────────────────

    private void forwardRequest(String method, String url,
                                 Map<String, String> headers,
                                 byte[] body,
                                 OutputStream clientOut) {
        try {
            URL u = new URL(url);
            HttpURLConnection conn;

            if (url.startsWith("https")) {
                HttpsURLConnection sc = (HttpsURLConnection) u.openConnection();
                sc.setSSLSocketFactory(trustAllFactory);
                sc.setHostnameVerifier((h, s) -> true);
                conn = sc;
            } else {
                conn = (HttpURLConnection) u.openConnection();
            }

            String safeMethod = "CONNECT".equalsIgnoreCase(method) ? "GET" : method.toUpperCase();
            conn.setRequestMethod(safeMethod);
            conn.setConnectTimeout(10_000);
            conn.setReadTimeout(10_000);
            conn.setInstanceFollowRedirects(true);

            // Forward request headers (skip hop-by-hop)
            for (Map.Entry<String, String> e : headers.entrySet()) {
                String k = e.getKey().toLowerCase();
                if (k.equals("connection") || k.equals("proxy-connection")
                        || k.equals("transfer-encoding")) continue;
                try { conn.setRequestProperty(e.getKey(), e.getValue()); }
                catch (Exception ignored) {}
            }

            // Send body for methods that have one
            if (body.length > 0 && (safeMethod.equals("POST")
                    || safeMethod.equals("PUT") || safeMethod.equals("PATCH"))) {
                conn.setDoOutput(true);
                conn.getOutputStream().write(body);
            }

            int code = conn.getResponseCode();
            byte[] respBody;
            try { respBody = readAll(conn.getInputStream()); }
            catch (Exception e) {
                InputStream err = conn.getErrorStream();
                respBody = err != null ? readAll(err) : new byte[0];
            }

            // Build response back to client
            StringBuilder sb = new StringBuilder();
            sb.append("HTTP/1.1 ").append(code).append(" OK\r\n");
            sb.append("Content-Length: ").append(respBody.length).append("\r\n");
            String ct = conn.getContentType();
            if (ct != null) sb.append("Content-Type: ").append(ct).append("\r\n");
            String enc = conn.getContentEncoding();
            if (enc != null) sb.append("Content-Encoding: ").append(enc).append("\r\n");
            sb.append("Connection: close\r\n\r\n");

            clientOut.write(sb.toString().getBytes("UTF-8"));
            clientOut.write(respBody);
            clientOut.flush();

        } catch (Exception e) {
            try {
                byte[] errBody = ("{\"error\":\"forward failed\"}").getBytes("UTF-8");
                clientOut.write(("HTTP/1.1 502 Bad Gateway\r\nContent-Length: "
                        + errBody.length + "\r\nConnection: close\r\n\r\n").getBytes());
                clientOut.write(errBody);
                clientOut.flush();
            } catch (Exception ignored) {}
        }
    }

    // ── I/O helpers ───────────────────────────────────────────────────────────

    private Map<String, String> readHeaders(BufferedReader reader) throws IOException {
        Map<String, String> h = new LinkedHashMap<>();
        String line;
        while ((line = reader.readLine()) != null && !line.isEmpty()) {
            int ci = line.indexOf(':');
            if (ci > 0) {
                h.put(line.substring(0, ci).trim().toLowerCase(),
                      line.substring(ci + 1).trim());
            }
        }
        return h;
    }

    private byte[] readBody(Map<String, String> headers, BufferedReader reader) {
        String lenStr = headers.get("content-length");
        if (lenStr == null) return new byte[0];
        try {
            int len = Integer.parseInt(lenStr.trim());
            if (len <= 0 || len > 10 * 1024 * 1024) return new byte[0];
            char[] chars = new char[len];
            int read = reader.read(chars, 0, len);
            return new String(chars, 0, Math.max(read, 0)).getBytes("UTF-8");
        } catch (Exception e) {
            return new byte[0];
        }
    }

    private byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] tmp = new byte[8192];
        int n;
        while ((n = in.read(tmp)) != -1) buf.write(tmp, 0, n);
        return buf.toByteArray();
    }

    // ── TLS helpers ───────────────────────────────────────────────────────────

    private KeyPair generateRsaKeyPair() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048, new SecureRandom());
        return kpg.generateKeyPair();
    }

    /**
     * Build a self-signed cert using Bouncy Castle if available,
     * otherwise fall back to sun.security.x509 reflection.
     * On modern Android (API 26+) the BC provider is available.
     */
    private X509Certificate buildSelfSignedCert(KeyPair kp) throws Exception {
        // Try Bouncy Castle / SpongyCastle path (usually available on Android)
        try {
            return buildCertBouncyCastle(kp);
        } catch (Throwable t) {
            Log.w(TAG, "BC cert gen failed, trying reflection: " + t.getMessage());
        }
        return buildCertReflection(kp);
    }

    @SuppressWarnings("unchecked")
    private X509Certificate buildCertBouncyCastle(KeyPair kp) throws Exception {
        // org.bouncycastle.* is bundled in Android under com.android.org.bouncycastle.*
        Class<?> x500PrincipalClass = Class.forName("javax.security.auth.x500.X500Principal");
        // Use Android's internal cert builder via KeyPairGenerator + KeyPairGeneratorSpec
        // Actually, simplest reliable path: use SpongyCastle if declared as dependency.
        // Since we don't have it as explicit dep, use the sun reflection path:
        throw new UnsupportedOperationException("fallthrough to reflection");
    }

    @SuppressWarnings({"unchecked", "JavaReflectionInvocation"})
    private X509Certificate buildCertReflection(KeyPair kp) throws Exception {
        Class<?> x500NameClass   = Class.forName("sun.security.x509.X500Name");
        Class<?> certInfoClass   = Class.forName("sun.security.x509.X509CertInfo");
        Class<?> certImplClass   = Class.forName("sun.security.x509.X509CertImpl");
        Class<?> algIdClass      = Class.forName("sun.security.x509.AlgorithmId");
        Class<?> validityClass   = Class.forName("sun.security.x509.CertificateValidity");
        Class<?> snClass         = Class.forName("sun.security.x509.CertificateSerialNumber");
        Class<?> algIdFieldClass = Class.forName("sun.security.x509.CertificateAlgorithmId");
        Class<?> subjectClass    = Class.forName("sun.security.x509.CertificateSubjectName");
        Class<?> issuerClass     = Class.forName("sun.security.x509.CertificateIssuerName");
        Class<?> keyClass        = Class.forName("sun.security.x509.CertificateX509Key");

        Object x500Name = x500NameClass.getConstructor(String.class)
                .newInstance("CN=NetInterceptorCA,O=Proxy,C=US");
        java.util.Date from = new java.util.Date();
        java.util.Date to   = new java.util.Date(from.getTime() + 10L * 365 * 24 * 3600 * 1000);
        Object validity  = validityClass.getConstructor(java.util.Date.class, java.util.Date.class)
                .newInstance(from, to);
        Object sn        = snClass.getConstructor(BigInteger.class)
                .newInstance(BigInteger.valueOf(System.currentTimeMillis()));
        Object algId     = algIdClass.getMethod("get", String.class).invoke(null, "SHA256withRSA");
        Object algIdField= algIdFieldClass.getConstructor(algId.getClass()).newInstance(algId);

        Object info = certInfoClass.newInstance();
        java.lang.reflect.Method set = certInfoClass.getMethod("set", String.class, Object.class);
        set.invoke(info, "validity",     validity);
        set.invoke(info, "serialNumber", sn);
        set.invoke(info, "subject",   subjectClass.getConstructor(x500NameClass).newInstance(x500Name));
        set.invoke(info, "issuer",    issuerClass.getConstructor(x500NameClass).newInstance(x500Name));
        set.invoke(info, "key",       keyClass.getConstructor(PublicKey.class).newInstance(kp.getPublic()));
        set.invoke(info, "algorithmID", algIdField);

        Object cert = certImplClass.getConstructor(certInfoClass).newInstance(info);
        certImplClass.getMethod("sign", PrivateKey.class, String.class)
                     .invoke(cert, kp.getPrivate(), "SHA256withRSA");
        return (X509Certificate) cert;
    }

    private SSLContext buildServerContext(KeyPair kp, X509Certificate cert) throws Exception {
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(null, null);
        ks.setKeyEntry("proxy", kp.getPrivate(), new char[0],
                new java.security.cert.Certificate[]{cert});
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(
                KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(ks, new char[0]);
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(kmf.getKeyManagers(), buildTrustAllManagers(), new SecureRandom());
        return ctx;
    }

    private SSLSocketFactory buildTrustAllFactory() throws Exception {
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, buildTrustAllManagers(), new SecureRandom());
        return ctx.getSocketFactory();
    }

    private TrustManager[] buildTrustAllManagers() {
        return new TrustManager[]{new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] c, String a) {}
            public void checkServerTrusted(X509Certificate[] c, String a) {}
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        }};
    }
}
